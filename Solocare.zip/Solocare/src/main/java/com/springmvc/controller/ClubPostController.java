package com.springmvc.controller;

public class ClubPostController {

}
