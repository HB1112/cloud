package com.springmvc.domain;

import java.util.Date;

public class clubMember 
{
	private String memberId;
	private int clubNum;
	private Date joinDate;
	

	public clubMember() {}
	
	public clubMember(String memberId, int clubNum, Date joinDate) {
		this.memberId = memberId;
		this.clubNum = clubNum;
		this.joinDate = joinDate;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public int getClubNum() {
		return clubNum;
	}

	public void setClubNum(int clubNum) {
		this.clubNum = clubNum;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	
	
	
}
