package com.springmvc.service;

import java.util.List;

import com.springmvc.domain.ClubPost;
import com.springmvc.repository.ClubPostRepository;

public class ClubPostServiceImpl implements ClubPostService
{

	@Override
	public void createPost(ClubPost post) {
		
		
	}

	@Override
	public List<ClubPost> getAllPosts(int page, int size) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotalPostCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
