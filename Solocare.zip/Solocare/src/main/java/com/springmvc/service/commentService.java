package com.springmvc.service;

import com.springmvc.domain.comment;

public interface commentService {

	void saveComment(comment comment);

}
