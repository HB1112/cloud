package com.springmvc.repository;

public class ClubPostRepositoryImpl {

}
