package com.springmvc.repository;

import com.springmvc.domain.comment;

public interface commentRepository {

	void saveComment(comment comment);
	
}
