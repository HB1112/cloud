package com.springmvc.domain;

public class PolicyDTO {
    private int rnum;
    private String polyBizSjnm;
    private String polyItcnCn;
    private String sporCn;
    private String sporScvl;
    private String prcpCn;
    private String ageInfo;
    private String majrRqisCn;
    private String empmSttsCn;
    private String rqutProcCn;
    private String rqutUrla;
    private String cherCtpcCn;
    private String polyBizSecd;
    private String rqutPrdCn;
	public int getRnum() {
		return rnum;
	}
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}
	public String getPolyBizSjnm() {
		return polyBizSjnm;
	}
	public void setPolyBizSjnm(String polyBizSjnm) {
		this.polyBizSjnm = polyBizSjnm;
	}
	public String getPolyItcnCn() {
		return polyItcnCn;
	}
	public void setPolyItcnCn(String polyItcnCn) {
		this.polyItcnCn = polyItcnCn;
	}
	public String getSporCn() {
		return sporCn;
	}
	public void setSporCn(String sporCn) {
		this.sporCn = sporCn;
	}
	public String getSporScvl() {
		return sporScvl;
	}
	public void setSporScvl(String sporScvl) {
		this.sporScvl = sporScvl;
	}
	public String getPrcpCn() {
		return prcpCn;
	}
	public void setPrcpCn(String prcpCn) {
		this.prcpCn = prcpCn;
	}
	public String getAgeInfo() {
		return ageInfo;
	}
	public void setAgeInfo(String ageInfo) {
		this.ageInfo = ageInfo;
	}
	public String getMajrRqisCn() {
		return majrRqisCn;
	}
	public void setMajrRqisCn(String majrRqisCn) {
		this.majrRqisCn = majrRqisCn;
	}
	public String getEmpmSttsCn() {
		return empmSttsCn;
	}
	public void setEmpmSttsCn(String empmSttsCn) {
		this.empmSttsCn = empmSttsCn;
	}
	public String getRqutProcCn() {
		return rqutProcCn;
	}
	public void setRqutProcCn(String rqutProcCn) {
		this.rqutProcCn = rqutProcCn;
	}
	public String getRqutUrla() {
		return rqutUrla;
	}
	public void setRqutUrla(String rqutUrla) {
		this.rqutUrla = rqutUrla;
	}
	public String getCherCtpcCn() {
		return cherCtpcCn;
	}
	public void setCherCtpcCn(String cherCtpcCn) {
		this.cherCtpcCn = cherCtpcCn;
	}
	public String getPolyBizSecd() {
		return polyBizSecd;
	}
	public void setPolyBizSecd(String polyBizSecd) {
		this.polyBizSecd = polyBizSecd;
	}
	public String getRqutPrdCn() {
		return rqutPrdCn;
	}
	public void setRqutPrdCn(String rqutPrdCn) {
		this.rqutPrdCn = rqutPrdCn;
	}

    // Getters and Setters
    
}
